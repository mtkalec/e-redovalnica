# e-redovalnica

Navodila za inštalacijo in ostala dokumentacija se nahaja v doc/